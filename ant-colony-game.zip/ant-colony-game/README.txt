ANT COLONY — QUICK START

1. Extract ant-colony-game.zip to a folder on your computer.
2. Open the extracted folder.
3. Double-click index.html to run the game in your browser.
   (You can also open the folder in VS Code and use Live Server.)

CONTROLS
- Move the red ant with W/A/S/D or the arrow keys.
- Walk over a berry to pick it up.
- Return to the anthill to store the berry.
- Collect 5 food and click “Hatch ant” to grow your colony.
- Click Restart to start over.

FILES
- index.html: game page
- style.css: visuals and layout
- script.js: game logic
- images/ant.png: your ant image with the white background removed

Nunito is loaded from Google Fonts when you're online. The game itself runs locally.
